// GameNet Khaghani API — Node.js 22+ (uses built-in node:sqlite)
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const PORT = Number(process.env.PORT || 8080);
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PUBLIC_DIR = path.join(__dirname, '..', 'public');
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(path.join(DATA_DIR, 'gamenet.sqlite'));
db.exec(`
PRAGMA journal_mode = WAL;
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS games (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, platform TEXT NOT NULL,
 category TEXT NOT NULL, price INTEGER NOT NULL CHECK(price >= 0), active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS reservations (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, device TEXT NOT NULL, date TEXT NOT NULL,
 time TEXT NOT NULL, duration INTEGER NOT NULL CHECK(duration BETWEEN 1 AND 12),
 people INTEGER NOT NULL DEFAULT 1, price INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, title TEXT NOT NULL, amount INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending', authority TEXT, ref_id TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS admin_sessions (
 token_hash TEXT PRIMARY KEY, expires_at INTEGER NOT NULL
);
`);
const count = db.prepare('SELECT COUNT(*) AS n FROM games').get().n;
if (!count) {
 const seed = db.prepare('INSERT INTO games(name,platform,category,price) VALUES(?,?,?,?)');
 [
  ['EA Sports FC 26','PS5','رقابتی',80000],['Call of Duty','PS5','رقابتی',90000],
  ['GTA V','PS4','کنسول',70000],['Mortal Kombat','PS5','رقابتی',75000],
  ['Minecraft','PC','کامپیوتر',60000],['Forza Horizon','Xbox','کنسول',85000]
 ].forEach(x=>seed.run(...x));
}
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const ZARINPAL_MERCHANT_ID = process.env.ZARINPAL_MERCHANT_ID || '';
const BASE_URL = (process.env.BASE_URL || '').replace(/\/$/,'');
const MAX_BODY = 1024 * 128;

function send(res, status, data, headers={}) {
 const body = typeof data === 'string' ? data : JSON.stringify(data);
 res.writeHead(status, {'Content-Type': typeof data === 'string' ? 'text/plain; charset=utf-8' : 'application/json; charset=utf-8', 'Cache-Control':'no-store', ...headers});
 res.end(body);
}
function readBody(req) {
 return new Promise((resolve,reject)=>{
  let raw=''; req.on('data',c=>{raw+=c;if(raw.length>MAX_BODY){reject(new Error('body too large'));req.destroy();}});
  req.on('end',()=>{try{resolve(raw?JSON.parse(raw):{});}catch{reject(new Error('invalid json'));}});
  req.on('error',reject);
 });
}
function hashPassword(password,salt=crypto.randomBytes(16).toString('hex')) {
 const hash=crypto.scryptSync(password,salt,64).toString('hex');
 return `${salt}:${hash}`;
}
function verifyPassword(password,stored) {
 const [salt,hex]=String(stored||'').split(':');
 if(!salt||!hex)return false;
 const actual=crypto.scryptSync(password,salt,64);
 const expected=Buffer.from(hex,'hex');
 return actual.length===expected.length && crypto.timingSafeEqual(actual,expected);
}
function adminOk(req) {
 if(!ADMIN_PASSWORD)return false;
 const token=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');
 if(!token)return false;
 const row=db.prepare('SELECT expires_at FROM admin_sessions WHERE token_hash=?').get(crypto.createHash('sha256').update(token).digest('hex'));
 return !!row && row.expires_at>Date.now();
}
function jsonSafeUser(row){return row?{id:row.id,name:row.name,phone:row.phone}:null}
function route(req,res){
 const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
 const p=url.pathname;
 (async()=>{
  if(req.method==='GET' && p==='/api/health') return send(res,200,{ok:true,service:'gamenet-api'});
  if(req.method==='GET' && p==='/api/games') return send(res,200,db.prepare('SELECT id,name,platform,category,price FROM games WHERE active=1 ORDER BY id DESC').all());
  if(req.method==='POST' && p==='/api/members/register'){
   const b=await readBody(req); const name=String(b.name||'').trim(),phone=String(b.phone||'').trim(),password=String(b.password||'');
   if(name.length<2||phone.length<5||password.length<8) return send(res,400,{error:'نام، شماره و رمز حداقل ۸ نویسه‌ای لازم است.'});
   try{
    const result=db.prepare('INSERT INTO users(name,phone,password_hash) VALUES(?,?,?)').run(name,phone,hashPassword(password));
    return send(res,201,{user:{id:Number(result.lastInsertRowid),name,phone}});
   }catch(e){if(String(e.message).includes('UNIQUE'))return send(res,409,{error:'این شماره قبلاً ثبت شده است.'});throw e;}
  }
  if(req.method==='POST' && p==='/api/members/login'){
   const b=await readBody(req),phone=String(b.phone||''),password=String(b.password||'');
   const row=db.prepare('SELECT * FROM users WHERE phone=?').get(phone);
   if(!row||!verifyPassword(password,row.password_hash))return send(res,401,{error:'شماره یا رمز نادرست است.'});
   // Member login returns profile only in this starter; production should issue a secure session.
   return send(res,200,{user:jsonSafeUser(row),notice:'برای نشست پایدار و احراز هویت کامل کاربر، پیکربندی امنیتی نهایی لازم است.'});
  }
  if(req.method==='POST' && p==='/api/admin/login'){
   const b=await readBody(req);
   const supplied=Buffer.from(String(b.password||'')); const expected=Buffer.from(ADMIN_PASSWORD); if(!ADMIN_PASSWORD || String(b.username)!==ADMIN_USER || supplied.length!==expected.length || !crypto.timingSafeEqual(supplied,expected))return send(res,401,{error:'ورود مدیر ناموفق بود. رمز مدیر را در متغیر محیطی ADMIN_PASSWORD تنظیم کنید.'});
   const token=crypto.randomBytes(32).toString('base64url'),tokenHash=crypto.createHash('sha256').update(token).digest('hex');
   db.prepare('INSERT INTO admin_sessions(token_hash,expires_at) VALUES(?,?)').run(tokenHash,Date.now()+8*60*60*1000);
   return send(res,200,{token,expiresInSeconds:28800});
  }
  if(p.startsWith('/api/admin/')){
   if(!adminOk(req))return send(res,401,{error:'دسترسی مدیر لازم است.'});
   if(req.method==='POST' && p==='/api/admin/games'){
    const b=await readBody(req),name=String(b.name||'').trim(),platform=String(b.platform||'').trim(),category=String(b.category||'کنسول').trim(),price=Number(b.price);
    if(!name||!platform||!Number.isSafeInteger(price)||price<0)return send(res,400,{error:'اطلاعات بازی یا قیمت نامعتبر است.'});
    const r=db.prepare('INSERT INTO games(name,platform,category,price) VALUES(?,?,?,?)').run(name,platform,category,price);
    return send(res,201,{id:Number(r.lastInsertRowid)});
   }
   const del=p.match(/^\/api\/admin\/games\/(\d+)$/);
   if(req.method==='DELETE'&&del){db.prepare('UPDATE games SET active=0 WHERE id=?').run(Number(del[1]));return send(res,200,{ok:true});}
   if(req.method==='GET'&&p==='/api/admin/reservations')return send(res,200,db.prepare(`SELECT r.*,u.name AS user_name,u.phone FROM reservations r LEFT JOIN users u ON u.id=r.user_id ORDER BY r.date,r.time`).all());
   const stat=p.match(/^\/api\/admin\/reservations\/(\d+)\/status$/);
   if(req.method==='PATCH'&&stat){const b=await readBody(req);const allowed=['pending','confirmed','cancelled','completed'];if(!allowed.includes(b.status))return send(res,400,{error:'وضعیت نامعتبر است.'});db.prepare('UPDATE reservations SET status=? WHERE id=?').run(b.status,Number(stat[1]));return send(res,200,{ok:true});}
   if(req.method==='GET'&&p==='/api/admin/orders')return send(res,200,db.prepare('SELECT id,title,amount,status,ref_id,created_at FROM orders ORDER BY id DESC').all());
   return send(res,404,{error:'مسیر مدیریتی پیدا نشد.'});
  }
  if(req.method==='POST' && p==='/api/reservations'){
   const b=await readBody(req);
   const device=String(b.device||''),date=String(b.date||''),time=String(b.time||''),duration=Number(b.duration),people=Number(b.people||1),userId=Number(b.userId)||null;
   if(!['PS5','PS4','PC','Xbox'].includes(device)||!/^\d{4}-\d{2}-\d{2}$/.test(date)||!/^\d{2}:\d{2}$/.test(time)||!Number.isInteger(duration)||duration<1||duration>12||!Number.isInteger(people)||people<1||people>8)return send(res,400,{error:'اطلاعات رزرو نامعتبر است.'});
   const start=new Date(`${date}T${time}:00`);if(Number.isNaN(start.getTime())||start.toISOString().slice(0,10)!==date)return send(res,400,{error:'تاریخ یا ساعت نامعتبر است.'});
   if(start.getTime()<Date.now()-60000)return send(res,400,{error:'زمان رزرو باید در آینده باشد.'});
   const startM=Number(time.slice(0,2))*60+Number(time.slice(3,5)),endM=startM+duration*60;
   if(endM>24*60)return send(res,400,{error:'مدت رزرو از پایان روز عبور می‌کند.'});
   // A conflict exists when the same device has any overlapping non-cancelled reservation.
   const existing=db.prepare(`SELECT id,time,duration FROM reservations WHERE device=? AND date=? AND status IN ('pending','confirmed')`).all(device,date);
   const conflict=existing.find(r=>{const m=Number(r.time.slice(0,2))*60+Number(r.time.slice(3,5));return startM<m+Number(r.duration)*60&&m<endM;});
   if(conflict)return send(res,409,{error:'این دستگاه در بخشی از زمان انتخابی رزرو شده است.',conflictId:conflict.id});
   const base=Number(process.env.BASE_TICKET_PRICE||80000),price=base*duration;
   const r=db.prepare('INSERT INTO reservations(user_id,device,date,time,duration,people,price) VALUES(?,?,?,?,?,?,?)').run(userId,device,date,time,duration,people,price);
   return send(res,201,{id:Number(r.lastInsertRowid),status:'pending',price,message:'درخواست رزرو ثبت شد و منتظر تأیید مدیر است.'});
  }
  if(req.method==='POST' && p==='/api/payments/create'){
   if(!ZARINPAL_MERCHANT_ID||!BASE_URL)return send(res,503,{error:'درگاه واقعی هنوز پیکربندی نشده است. BASE_URL و ZARINPAL_MERCHANT_ID لازم‌اند.'});
   const b=await readBody(req),amount=Number(b.amount),title=String(b.title||'خرید گیم‌نت').slice(0,120);
   if(!Number.isSafeInteger(amount)||amount<1000||amount>1000000000)return send(res,400,{error:'مبلغ پرداخت نامعتبر است.'});
   const result=db.prepare('INSERT INTO orders(title,amount,status) VALUES(?,?,?)').run(title,amount,'pending');
   const orderId=Number(result.lastInsertRowid);
   const response=await fetch('https://api.zarinpal.com/pg/v4/payment/request.json',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({merchant_id:ZARINPAL_MERCHANT_ID,amount,callback_url:`${BASE_URL}/api/payments/verify?orderId=${orderId}`,description:title,metadata:{order_id:String(orderId)}})});
   const data=await response.json();const authority=data?.data?.authority;
   if(!authority){db.prepare('UPDATE orders SET status=? WHERE id=?').run('failed',orderId);return send(res,502,{error:'درگاه پرداخت درخواست را نپذیرفت.',details:data?.errors||data?.data||null});}
   db.prepare('UPDATE orders SET authority=? WHERE id=?').run(authority,orderId);
   return send(res,200,{orderId,paymentUrl:`https://www.zarinpal.com/pg/StartPay/${authority}`});
  }
  if(req.method==='GET' && p==='/api/payments/verify'){
   const orderId=Number(url.searchParams.get('orderId')),authority=url.searchParams.get('Authority'),status=url.searchParams.get('Status');
   const order=db.prepare('SELECT * FROM orders WHERE id=?').get(orderId);
   if(!order||!authority||order.authority!==authority)return send(res,400,'سفارش یا شناسه پرداخت معتبر نیست.');
   if(status!=='OK'){db.prepare('UPDATE orders SET status=? WHERE id=?').run('cancelled',orderId);return send(res,200,'پرداخت لغو شد. می‌توانید به برنامه برگردید.');}
   const response=await fetch('https://api.zarinpal.com/pg/v4/payment/verify.json',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({merchant_id:ZARINPAL_MERCHANT_ID,amount:order.amount,authority})});
   const data=await response.json(),code=data?.data?.code;
   if(code===100||code===101){const ref=String(data.data.ref_id||'');db.prepare('UPDATE orders SET status=?,ref_id=? WHERE id=?').run('paid',ref,orderId);return send(res,200,`پرداخت تأیید شد. شماره پیگیری: ${ref}`);}
   db.prepare('UPDATE orders SET status=? WHERE id=?').run('failed',orderId);return send(res,400,'تأیید پرداخت ناموفق بود.');
  }
  // Static PWA
  if(req.method==='GET'){
   let file=p==='/'?'index.html':decodeURIComponent(p.slice(1));
   const full=path.resolve(PUBLIC_DIR,file);
   if(!full.startsWith(path.resolve(PUBLIC_DIR)+path.sep))return send(res,403,'Forbidden');
   fs.readFile(full,(err,buf)=>{if(err)return send(res,404,'Not found');const ext=path.extname(full);const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/manifest+json','.png':'image/png','.css':'text/css; charset=utf-8'};res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream','X-Content-Type-Options':'nosniff'});res.end(buf);});
   return;
  }
  return send(res,404,{error:'مسیر پیدا نشد.'});
 })().catch(err=>{console.error(err);if(!res.headersSent)send(res,500,{error:'خطای داخلی سرور'});});
}
http.createServer(route).listen(PORT,HOST,()=>console.log(`GameNet API running at http://localhost:${PORT}`));
